=== Smart Google Map ===
Contributors: imdr
Donate link: https://imdr.github.io/donate
Tags: google map, map, smart google map, dynamic map, dynamic google map, marker
Requires at least: 4.6
Tested up to: 4.8.2
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This is a simple and smart Google Map plugin. 

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)


== Frequently Asked Questions ==
[Ask me anything!](https://github.com/ImDR/smart-google-map).

== Screenshots ==
 
1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png
5. screenshot-5.png
6. screenshot-6.png
7. screenshot-7.png
8. screenshot-8.png

== Changelog ==

= 1.5 =
Get more information, see [here](https://github.com/ImDR/smart-google-map).
 
== Upgrade Notice ==
 
= 1.5 =
Get more information, see [here](https://github.com/ImDR/smart-google-map).
